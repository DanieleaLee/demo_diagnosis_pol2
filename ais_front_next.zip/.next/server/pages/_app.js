/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_css_global_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @styles/css/global.scss */ \"./src/styles/css/global.scss\");\n/* harmony import */ var _styles_css_global_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_css_global_scss__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _recoil_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @recoil/constants */ \"./src/recoil/constants.ts\");\n/* harmony import */ var src_config_init__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/config/init */ \"./src/config/init.ts\");\n/* harmony import */ var _emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @emotion/react/jsx-dev-runtime */ \"@emotion/react/jsx-dev-runtime\");\n/* harmony import */ var _emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__);\nvar _jsxFileName = \"E:\\\\v5\\\\aistudio\\\\front\\\\ais_front_next\\\\pages\\\\_app.tsx\";\n\nfunction ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }\n\nfunction _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }\n\nfunction _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }\n\n\n\n\n\n\n\n\n\nfunction MyApp({\n  Component,\n  pageProps\n}) {\n  const initializeState = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(async ({\n    set\n  }) => {\n    set({\n      key: _recoil_constants__WEBPACK_IMPORTED_MODULE_4__.Atoms.User\n    }, pageProps.user);\n  }, []);\n  return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(recoil__WEBPACK_IMPORTED_MODULE_3__.RecoilRoot, {\n    initializeState: initializeState,\n    children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(Component, _objectSpread({}, pageProps), void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 18,\n      columnNumber: 7\n    }, this)\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 17,\n    columnNumber: 5\n  }, this);\n}\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBLFNBQVNHLEtBQVQsQ0FBZTtBQUFFQyxFQUFBQSxTQUFGO0FBQWFDLEVBQUFBO0FBQWIsQ0FBZixFQUFtRDtBQUVqRCxRQUFNQyxlQUFlLEdBQUdOLGtEQUFXLENBQUMsT0FBTTtBQUFDTyxJQUFBQTtBQUFELEdBQU4sS0FBZ0I7QUFDbERBLElBQUFBLEdBQUcsQ0FBQztBQUFDQyxNQUFBQSxHQUFHLEVBQUVOLHlEQUFVTztBQUFoQixLQUFELEVBQW9CSixTQUFTLENBQUNLLElBQTlCLENBQUg7QUFDRCxHQUZrQyxFQUVoQyxFQUZnQyxDQUFuQztBQUlBLFNBQ0UsdUVBQUMsOENBQUQ7QUFBWSxtQkFBZSxFQUFFSixlQUE3QjtBQUFBLGNBQ0UsdUVBQUMsU0FBRCxvQkFBZUQsU0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBS0Q7O0FBRUQsaUVBQWVGLEtBQWYiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zYl9haXN0dWRpby8uL3BhZ2VzL19hcHAudHN4PzJmYmUiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICcuLi9zdHlsZXMvZ2xvYmFscy5jc3MnXHJcbmltcG9ydCB7IEFwcFByb3BzIH0gZnJvbSAnbmV4dC9hcHAnO1xyXG5pbXBvcnQgXCJAc3R5bGVzL2Nzcy9nbG9iYWwuc2Nzc1wiO1xyXG5pbXBvcnQge3VzZUNhbGxiYWNrfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHtSZWNvaWxSb290fSBmcm9tIFwicmVjb2lsXCI7XHJcbmltcG9ydCB7QXRvbXN9IGZyb20gXCJAcmVjb2lsL2NvbnN0YW50c1wiO1xyXG5pbXBvcnQgXCJzcmMvY29uZmlnL2luaXRcIjtcclxuXHJcblxyXG5mdW5jdGlvbiBNeUFwcCh7IENvbXBvbmVudCwgcGFnZVByb3BzIH06IEFwcFByb3BzKSB7XHJcblxyXG4gIGNvbnN0IGluaXRpYWxpemVTdGF0ZSA9IHVzZUNhbGxiYWNrKGFzeW5jKHtzZXR9KSA9PiB7XHJcbiAgICBzZXQoe2tleTogQXRvbXMuVXNlcn0sIHBhZ2VQcm9wcy51c2VyKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8UmVjb2lsUm9vdCBpbml0aWFsaXplU3RhdGU9e2luaXRpYWxpemVTdGF0ZX0+XHJcbiAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30vPlxyXG4gICAgPC9SZWNvaWxSb290PlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IE15QXBwXHJcbiJdLCJuYW1lcyI6WyJ1c2VDYWxsYmFjayIsIlJlY29pbFJvb3QiLCJBdG9tcyIsIk15QXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIiwiaW5pdGlhbGl6ZVN0YXRlIiwic2V0Iiwia2V5IiwiVXNlciIsInVzZXIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/_app.tsx\n");

/***/ }),

/***/ "./src/config/init.ts":
/*!****************************!*\
  !*** ./src/config/init.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _recoil_atoms_user__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @recoil/atoms/user */ "./src/recoil/atoms/user.ts");


/***/ }),

/***/ "./src/recoil/atoms/user.ts":
/*!**********************************!*\
  !*** ./src/recoil/atoms/user.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"userState\": () => (/* binding */ userState)\n/* harmony export */ });\n/* harmony import */ var _recoil_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @recoil/constants */ \"./src/recoil/constants.ts\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst userState = (0,recoil__WEBPACK_IMPORTED_MODULE_1__.atom)({\n  key: _recoil_constants__WEBPACK_IMPORTED_MODULE_0__.Atoms.User,\n  default: undefined\n});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcmVjb2lsL2F0b21zL3VzZXIudHMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUNBO0FBQ0E7QUFHTyxNQUFNRSxTQUFTLEdBQUdELDRDQUFJLENBQU87QUFDbENFLEVBQUFBLEdBQUcsRUFBRUgseURBRDZCO0FBRWxDSyxFQUFBQSxPQUFPLEVBQUVDO0FBRnlCLENBQVAsQ0FBdEIiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zYl9haXN0dWRpby8uL3NyYy9yZWNvaWwvYXRvbXMvdXNlci50cz8wYmViIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFVzZXIgfSBmcm9tIFwiQGludGVyZmFjZXMvbW9kZWxcIjtcclxuaW1wb3J0IHsgQXRvbXMgfSBmcm9tIFwiQHJlY29pbC9jb25zdGFudHNcIjtcclxuaW1wb3J0IHsgYXRvbSB9IGZyb20gXCJyZWNvaWxcIjtcclxuXHJcblxyXG5leHBvcnQgY29uc3QgdXNlclN0YXRlID0gYXRvbTxVc2VyPih7XHJcbiAga2V5OiBBdG9tcy5Vc2VyLFxyXG4gIGRlZmF1bHQ6IHVuZGVmaW5lZCxcclxufSk7XHJcbiJdLCJuYW1lcyI6WyJBdG9tcyIsImF0b20iLCJ1c2VyU3RhdGUiLCJrZXkiLCJVc2VyIiwiZGVmYXVsdCIsInVuZGVmaW5lZCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/recoil/atoms/user.ts\n");

/***/ }),

/***/ "./src/recoil/constants.ts":
/*!*********************************!*\
  !*** ./src/recoil/constants.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"Atoms\": () => (/* binding */ Atoms)\n/* harmony export */ });\nlet Atoms;\n\n(function (Atoms) {\n  Atoms[\"User\"] = \"User\";\n})(Atoms || (Atoms = {}));//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcmVjb2lsL2NvbnN0YW50cy50cy5qcyIsIm1hcHBpbmdzIjoiOzs7O0FBQU8sSUFBS0EsS0FBWjs7V0FBWUE7QUFBQUEsRUFBQUE7R0FBQUEsVUFBQUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zYl9haXN0dWRpby8uL3NyYy9yZWNvaWwvY29uc3RhbnRzLnRzP2QwMDgiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGVudW0gQXRvbXMge1xyXG4gIFVzZXIgPSBcIlVzZXJcIixcclxufSJdLCJuYW1lcyI6WyJBdG9tcyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/recoil/constants.ts\n");

/***/ }),

/***/ "./src/styles/css/global.scss":
/*!************************************!*\
  !*** ./src/styles/css/global.scss ***!
  \************************************/
/***/ (() => {



/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "@emotion/react/jsx-dev-runtime":
/*!*************************************************!*\
  !*** external "@emotion/react/jsx-dev-runtime" ***!
  \*************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@emotion/react/jsx-dev-runtime");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "recoil":
/*!*************************!*\
  !*** external "recoil" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("recoil");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.tsx"));
module.exports = __webpack_exports__;

})();